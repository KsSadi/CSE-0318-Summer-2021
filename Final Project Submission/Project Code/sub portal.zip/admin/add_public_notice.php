<?php 
include('parts/header.php');
include('form/add_public_notice.php');
include('parts/head.php');
include('parts/navbar.php');
include('parts/sidebar.php');
include('parts/content_add_public_notice.php');
include('parts/footer.php');

?>