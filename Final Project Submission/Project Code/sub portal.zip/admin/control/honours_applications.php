<?php 
$sql = "SELECT id, year_date,semester_month, admission_roll, date, status FROM honours_application";
$query = mysqli_query($conn, $sql);

?>