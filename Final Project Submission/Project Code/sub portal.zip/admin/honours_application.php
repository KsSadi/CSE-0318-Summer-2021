<?php 
include('parts/header.php');
include('control/honours_application.php');
include('parts/head.php');
include('parts/navbar.php');
include('parts/sidebar.php');
include('parts/content_honours_application.php');
include('parts/footer.php');

?>