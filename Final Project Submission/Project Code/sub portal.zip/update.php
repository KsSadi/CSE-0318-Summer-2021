<?php
include('parts/header.php');
include('form/update.php');

include('parts/head.php');
include('parts/navbar.php');

include('parts/content_update.php');

include('parts/footer.php');
?>