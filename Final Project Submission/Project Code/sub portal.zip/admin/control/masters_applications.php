<?php 
$sql = "SELECT id, exam_name, admission_roll, date, status FROM masters_application";
$query = mysqli_query($conn, $sql);

?>