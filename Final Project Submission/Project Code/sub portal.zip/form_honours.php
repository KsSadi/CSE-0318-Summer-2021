<?php
include('parts/header.php');
include('control/form_honours.php');
include('parts/content_form_honours.php');
//include('parts/content_admit_honours.php');
?>