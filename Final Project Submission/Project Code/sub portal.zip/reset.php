<?php
include('parts/header.php');
include('form/reset.php');

include('parts/head.php');
include('parts/navbar.php');

include('parts/content_reset.php');
include('parts/sidebar.php');
include('parts/footer.php');
?>