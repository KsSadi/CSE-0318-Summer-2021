<?php

$sql = "SELECT admission_roll, name_en, mobile_no, picture, id, name_f , dept_s FROM students";
$query = mysqli_query($conn, $sql);


?>