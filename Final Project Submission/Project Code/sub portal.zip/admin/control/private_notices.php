<?php

$sql = "SELECT admission_roll, title, message, date FROM private_notice";
$query = mysqli_query($conn, $sql);


?>