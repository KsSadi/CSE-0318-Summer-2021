<?php 
include('parts/header.php');
include('form/student_edit.php');
include('parts/head.php');
include('parts/navbar.php');
include('parts/sidebar.php');
include('parts/content_student_edit.php');
include('parts/footer.php');

?>