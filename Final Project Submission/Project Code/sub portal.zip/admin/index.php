<?php 
include('parts/header.php');
include('control/index.php');
include('parts/head.php');
include('parts/navbar.php');
include('parts/sidebar.php');
include('parts/content_index.php');
include('parts/footer.php');

?>