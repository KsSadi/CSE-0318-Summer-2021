<?php
include('parts/header.php');
include('form/register.php');

//include('parts/head.php');
//include('parts/navbar.php');

//include('parts/content_register.php');
include('parts/content_register.php');

include('parts/footer.php');
?>