<?php 
$sql = "SELECT * FROM improvement_application ORDER BY date DESC";
$query = mysqli_query($conn, $sql);

?>