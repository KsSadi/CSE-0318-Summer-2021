<?php

$sql = "SELECT title, message, files, date FROM public_notice";
$query = mysqli_query($conn, $sql);


?>