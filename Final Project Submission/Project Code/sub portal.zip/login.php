<?php
include('parts/header.php');
include('form/login.php');

//include('parts/head.php');
//include('parts/navbar.php');

include('parts/content_login.php');
//include('parts/sidebar.php');
//include('parts/footer.php');
?>

