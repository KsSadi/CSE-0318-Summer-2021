<?php 
include('parts/header.php');
include('control/public_notices.php');
include('parts/head.php');
include('parts/navbar.php');
include('parts/sidebar.php');
include('parts/content_public_notices.php');
include('parts/footer.php');

?>