<?php
include('parts/header.php');
include('control/applications.php');
//include('parts/head.php');
include('parts/navbar.php');



include('parts/content_applications.php');


include('parts/footer.php');
?>