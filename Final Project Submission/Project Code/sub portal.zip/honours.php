<?php
include('parts/header.php');
include('form/honours.php');

//include('parts/head.php');
include('parts/navbar.php');

include('parts/content_honours.php');

include('parts/footer.php');
?>